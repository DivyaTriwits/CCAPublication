<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller{
    
    function  __construct(){
        parent::__construct();
        
        // Load paypal library & product model
        $this->load->library('paypal_lib');
        $this->load->model('product');
    }
    
    function index(){
        $data = array();
        
        // Get products data from the database
        $data['products'] = $this->product->getRows();
        
        // Pass products data to the view
        $this->load->view('products/index', $data);
    }
    
    function buy($id){
        // Set variables for paypal form
        $returnURL = base_url().'paypal/success';
        $cancelURL = base_url().'paypal/cancel';
        $notifyURL = base_url().'paypal/ipn';
        
        // Get product data from the database
        // $product = $this->product->getRows($id);
        
        $roomBookInfo = $this->db->get_where('roombook',array("id" => $id))->row();
        
        // Get current user ID from the session
        //$userID = $_SESSION['userID'];

        $userID = 'reachus@triwits.com';
        
        // Add fields to paypal form
        $this->paypal_lib->add_field('return', $returnURL);
        $this->paypal_lib->add_field('cancel_return', $cancelURL);
        $this->paypal_lib->add_field('notify_url', $notifyURL);
        $this->paypal_lib->add_field('item_name', $roomBookInfo->TRoom." ".$roomBookInfo->Bed." ".$roomBookInfo->NRoom);
        $this->paypal_lib->add_field('custom', $roomBookInfo->Email);
        $this->paypal_lib->add_field('item_number',  $id);
        $this->paypal_lib->add_field('amount',  $_GET['price']);
        
        // Render paypal form
        $this->paypal_lib->paypal_auto_form();


    }
}
<?php

Class Response extends CI_Model{
  Public function calculate(){
    return 10;
  }
} // End of Class

?>